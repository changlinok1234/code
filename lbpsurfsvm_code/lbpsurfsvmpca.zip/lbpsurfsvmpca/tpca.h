#ifndef __tmp__tpca__
#define __tmp__tpca__
#include <opencv/cv.h>
#include <opencv2/core.hpp>
#include <opencv2/ml.hpp>
#include <iostream>
#include <fstream>
#include "opencv2/features2d/features2d.hpp"
#include "opencv2/highgui/highgui.hpp"

using namespace cv;
using namespace std;
Mat tpca(Mat& featuredata,Mat& datamatrix );

#endif
